---
## Front matter
title: "Отчет по курсу"
subtitle: "Основы кибербезопасности"
author: "Камалиева Лия Дамировна"

## Generic otions
lang: ru-RU
toc-title: "Содержание"

## Bibliography
bibliography: bib/cite.bib
csl: pandoc/csl/gost-r-7-0-5-2008-numeric.csl

## Pdf output format
toc: true # Table of contents
toc-depth: 2
lof: true # List of figures
lot: true # List of tables
fontsize: 12pt
linestretch: 1.5
papersize: a4
documentclass: scrreprt
## I18n polyglossia
polyglossia-lang:
  name: russian
  options:
	- spelling=modern
	- babelshorthands=true
polyglossia-otherlangs:
  name: english
## I18n babel
babel-lang: russian
babel-otherlangs: english
## Fonts
mainfont: PT Serif
romanfont: PT Serif
sansfont: PT Sans
monofont: PT Mono
mainfontoptions: Ligatures=TeX
romanfontoptions: Ligatures=TeX
sansfontoptions: Ligatures=TeX,Scale=MatchLowercase
monofontoptions: Scale=MatchLowercase,Scale=0.9
## Biblatex
biblatex: true
biblio-style: "gost-numeric"
biblatexoptions:
  - parentracker=true
  - backend=biber
  - hyperref=auto
  - language=auto
  - autolang=other*
  - citestyle=gost-numeric
## Pandoc-crossref LaTeX customization
figureTitle: "Рис."
tableTitle: "Таблица"
listingTitle: "Листинг"
lofTitle: "Список иллюстраций"
lotTitle: "Список таблиц"
lolTitle: "Листинги"
## Misc options
indent: true
header-includes:
  - \usepackage{indentfirst}
  - \usepackage{float} # keep figures where there are in the text
  - \floatplacement{figure}{H} # keep figures where there are in the text
---

# Цель работы

развить навыки защиты информации, в повседневной жизни, а также работе


# Выполнение курса

Задание 38. один для шифрования и дешифрования, не может быть такого что одна использует а другая сторона держит его в сектрете, у каждого свой ключ

![рис.1.38](image/41.jpg)

Задание 39. да она вычисляется эффективно, насчет бит также, она всегда выдает один результат, эти функции не предназначены для шифрования и защиты данных от просмотра

![рис.1.39](image/42.jpg)

Задание 40. AES нет это симментричный алгоритм, SHA2 семейство функций

![рис.1.40](image/43.jpg)

Задание 41. симметричным тк используют пару ключей

![рис.1.41](image/44.jpg)

Задание 42. ассиметричный и секретный ключ

![рис.1.42](image/45.jpg)

Задание 43. второй вариант тк они используют один ключ

![рис.1.43](image/46.jpg)

Задание 44. на вход требуют подпись открытый ключ и исходное сообщени чтобы удостовериться в том что не было узменений после подписания

![рис.1.44](image/47.jpg)

Задание 45. обеспечивает но только владелец секретного ключа тк он модет создать подпись, а вот конфиденциальности нет

![рис.1.45](image/48.jpg)

Задание 46. по законодательсьву первый вариант не признается фнс, только внутренний оборот

![рис.1.45](image/49.jpg)

Задание 47. первое не отностится, 2 ведет реестр, 4 точно нет

![рис.1.47](image/50.jpg)

Задание 48. мир это система платежей в России, а мастер кард используетсяво всем мире

![рис.1.48](image/51.jpg)

Задание 49. капча -- защита от ботов, а пин код пароль это не MFA а знание

![рис.1.49](image/52.jpg)

Задание 50. современные стандарты требуют MFA, а не однофакторной аутентифирации

![рис.1.50](image/53.jpg)

Задание 51. хэш функции должны быть быстрыми, но в PoW требуется намеренное усложнение

![рис.1.51](image/54.jpg)

Задание 52. открытость кода не является обязательным свойством для всех блокчейн сетей

![рис.1.52](image/55.jpg)

Задание 53. участники блокчейна хранят секретные ключи только для цифровых подписей, чтобы подписывать транзакции

![рис.1.53](image/56.jpg)

Итог по прохождению курса

![рис.1.54](image/0.0.jpg)





# Выводы
во время прохождения курса я поняла  ключевые аспекты криптографии, блокчейна и кибербезопасности, включая различия между симметричным и асимметричным шифрованием, принципы цифровых подписей, многофакторную аутентификацию, уязвимости (фишинг, трояны) и особенности PoW в блокчейне.


# Список литературы{.unnumbered}
